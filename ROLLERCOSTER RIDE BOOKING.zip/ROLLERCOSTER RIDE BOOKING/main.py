# Online Python Playground
# Use the online IDE to write, edit & run your Python code
# Create, edit & delete files online

print("Welcome to the rollercoster !!")
height=int(input("What is your height in cm?"))
bill=0

if height >=120:
    print("Great !! You can enjoy the ride!!")
    age=int(input("What is your age?"))
    if age < 12:
        bill = 5
        print ("Child tickets are $5")
    elif age <=18:
        bill=8
        print ("Youth tickets are 8$")
    elif age >=45 and age <= 55:
        print("Everything is going to be okay. Have a free ride on us!")
    else:
        bill=12
        print("Adult tickets are 12$")
   
    
    wants_photo= input("Do you want your photos to be taken?? Y or N")
    if wants_photo == "Y":
        bill += 3
    
    print(f"Your final bill is {bill}")
else:
    print("Sorry you can't ride!!")